<?php
 
 function creatUser($data){
    $conn = mysql_connect("localhost","username","password","database");

    if (!$conn){
        die("Connection failed: " . mysqli_connect_eror());
    }
    $query = "INSERT INTO user(name, email, password) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);

    mysqli_stmt_bind_param($stmt, "sss", $data['name'], $data['email'], $data['password']);

    mysqli_stmt_execute($stmt);

    mysqli_close($conn);
    return "User created successfully";

 }
 //Пример
 $data = array('name' => 'John Doe', 'email' => 'john@example.com', 'password' => '1234');
 echo createUser($data);
 ?>