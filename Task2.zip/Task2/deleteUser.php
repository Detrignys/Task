<?php

function delereUser($id){
    $conn = mysqli_connect("localhost", "username", "password", "database");
    if (!$conn){
        die("Connection failed: " . mysqli_connect_error());
    }
    $query = "DELETE FROM users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_close($conn);

    return "User delered successfully";
}
//пример
$id = 1;
echo deleteUser($id);
?>