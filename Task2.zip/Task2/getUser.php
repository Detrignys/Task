<?php

function getUser($id){
    $conn = mysqli_connect("localhost", "username", "password", "database");
    if (!$conn){
        die("Connection failed: " . mysqli_connect_error());
    }

    $query = "SELECT * FROM users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if (mysqli_num_rows($result) > 0){
        while ($row = mysqli_fetch_assoc($result)){
            echo "ID: " . $row['id'] . "<br>";
            echo "Name: " . $row['name'] . '<br>';
            echo "Email: " . $row['email'] . "<br>";
        }
    }
    else{
        echo "User not found";
    }
    mysqli_close($conn);
}
// пример
$id = 1;
getUser($id);
?>

