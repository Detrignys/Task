<?php
function updateUser($id, $data){
    $conn = mysqli_connect("localhost", "username", "password", "database");

    if (!$conn){
        die("Connect failed: " . mysqli_connect_error());

    }
    $query = "UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_peram($stmt, "sssi", $data['name'], $data['email'], $data['password'], $id);
    mysqli_close($conn);
    return "User updated seccessfully"

}
//пример
$id = 1;
$data = array('name' => 'Jane Doe', 'email' => 'jane@example.com', 'password' => 'newpassword');
echo updateUser($id, $data);
?>
