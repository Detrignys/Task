<?php

function authenticateUser($email, $password){
    $conn = mysqli_connect("localhost", "username", 'password', "database");

    if (!$conn){
        die("Connection failed: " . mysqli_connect_error());
    }
    $query = "SELECT * FROM users WHERE email = ? AND password = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ss", $email, $password);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if (mysqli_num_rows($result) > 0){
        return true;
    }
    else {
        return false;
    }
    mysqli_cloase($conn);
}
//пример
$email = 'john@example.com';
$password = 'password123';
if (authenticateUser($email, $password)) {
    echo "User authenticated successfully";
} else {
    echo "Invalid credentials";
}
?>