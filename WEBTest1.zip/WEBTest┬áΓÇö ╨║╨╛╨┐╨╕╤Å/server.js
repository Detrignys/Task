const express = require('express');
const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true}));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/submit', (req, res) => {
    const {name, email, message } = req.body;
    res.send('Сообщение отправлено!')
})
app.listen(port, () => {
    console.log('Server start port ${port}');
})